# Consulting Storyline

Use this reference when creating a new deck or changing its core narrative.

## Decision brief

Answer these before outlining slides:

- Who will decide or act?
- What decision must the meeting enable?
- What happens if nothing changes?
- What does the audience currently believe?
- What should they believe or do after the deck?
- Which facts are verified, disputed, assumed, or missing?

## SCQA opening

- **Situation:** stable context the audience already accepts.
- **Complication:** the change, constraint, or tension that makes action necessary.
- **Question:** the decision the deck must answer.
- **Answer:** the governing thought, expressed as a recommendation or conclusion.

Do not force one slide per letter. SCQA is a reasoning pattern; the opening may use one page or several depending on the audience's familiarity.

## Pyramid body

Start with the governing thought. Support it with 2–4 mutually distinct arguments. Under each argument, group evidence that is logically parallel.

Good sibling groups share the same basis, for example:

- customer, economics, and capability;
- demand, supply, and regulation;
- now, next, and later;
- impact, feasibility, and risk.

Avoid lists that mix causes, examples, actions, and outcomes at one level.

## Issue trees

Use an issue tree to decide what must be analyzed, not merely to decorate a slide. Each branch should be:

- relevant to the decision;
- distinct enough to avoid double counting;
- collectively sufficient for the working question;
- testable with evidence.

Stop decomposing when the next level no longer changes the decision or can be assigned a concrete analysis.

## Common deck arcs

### Recommendation deck

1. Governing thought and ask
2. Why action is needed now
3. Evidence for supporting argument 1
4. Evidence for supporting argument 2
5. Options and trade-offs
6. Recommendation
7. Impact, risks, and implementation
8. Decision and next steps

### Diagnostic deck

1. Executive diagnosis
2. Performance baseline
3. Where the gap occurs
4. Why it occurs
5. What matters most
6. Intervention options
7. Recommended actions and measurement

### Proposal deck

1. Client context and ambition
2. Specific challenge
3. Point of view / hypothesis
4. Proposed work and outputs
5. Evidence or relevant experience
6. Workplan, governance, and team
7. Commercials or next step

### Executive update

1. Headline status and decision needed
2. Progress against outcomes
3. Material variance and cause
4. Risks and mitigations
5. Next milestones and owners

## Title storyline test

Read only the slide titles. They should form a complete argument with no unexplained jumps. If two neighboring titles could swap places without affecting the logic, the sequence is probably weak. If several titles repeat the same idea, combine or deepen them.
