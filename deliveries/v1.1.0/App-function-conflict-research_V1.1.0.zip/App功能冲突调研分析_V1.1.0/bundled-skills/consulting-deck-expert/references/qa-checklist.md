# Consulting Deck QA

## Argument

- The audience and requested decision are explicit.
- The governing thought answers the central question.
- Supporting arguments are distinct, sufficient, and ordered logically.
- The title sequence reads as a coherent executive summary.
- Every body exhibit proves or qualifies its title.
- Alternatives, trade-offs, and material risks are visible.
- The final ask specifies who decides what and by when.

## Evidence

- Facts, interpretations, assumptions, and recommendations are distinguishable.
- Numbers reconcile across slides and use consistent units and periods.
- Sources are present and close to the relevant exhibit.
- Missing evidence is labeled; no placeholder is presented as fact.
- Examples and customer stories are not generalized beyond their evidence.

## Slide craft

- Each slide has one governing message.
- Content is readable at normal presentation distance.
- No orphan lines, accidental wrapping, clipping, or overlap remains.
- Charts use honest scales and direct labels.
- Repeated elements share geometry and spacing.
- Decorative elements do not compete with the evidence.
- Appendix pages contain useful support rather than discarded clutter.

## Delivery readiness

- Brand, confidentiality, and legal constraints are respected.
- Editable elements remain editable where practical.
- Fonts and assets are embedded, packaged, or safely substituted.
- PPTX/PDF renders have been visually checked page by page.
- Speaker notes, hidden slides, comments, and metadata have been reviewed for unintended disclosure.
