# Exhibit Patterns

Choose the exhibit that most directly proves the slide title.

| Question | Good default | Avoid |
|---|---|---|
| How much / how fast? | bar, line, slope, indexed trend | decorative gauges |
| What changed? | variance bridge, before/after with quantified deltas | two unlabeled screenshots |
| Why did it change? | driver tree, decomposition, waterfall | a list of unrelated causes |
| Which option wins? | criteria matrix, value-versus-feasibility plot | unsupported 2×2 placement |
| Where is the opportunity? | segment bars, heatmap, opportunity map | oversized bubble chart with vague sizing |
| How does it work? | process, system map, operating model | dense spaghetti arrows |
| What happens when? | milestone roadmap, dependency path | calendar boxes without outcomes |
| Who owns what? | responsibility matrix, swimlane | organization chart used as a process |
| What is the evidence? | annotated quote, case strip, precise table | walls of prose |

## Quantitative exhibits

- State units, time periods, definitions, and sources.
- Use a common baseline for comparisons.
- Sort bars when order carries meaning.
- Label important values directly and reduce legend travel.
- Use a zero baseline for ordinary bars; disclose intentional truncation.
- Avoid dual axes unless the relationship cannot be shown more honestly another way.
- Do not create a chart when the message is a single number with one comparison.

## Matrices and portfolios

Define both axes, directionality, scoring method, and size encoding. Plot positions from evidence or clearly labeled judgment. A 2×2 should lead to a decision, such as invest, test, maintain, or exit.

## Processes and systems

Show direction, boundaries, inputs, outputs, feedback loops, and owners only when they matter. Use consistent node shapes for consistent object types. Route connectors cleanly and avoid crossing labels.

## Roadmaps

Organize by outcomes or workstreams. Show dependencies and decision gates. Separate committed work from options, and distinguish elapsed time from effort.

## Tables

Use tables when the reader must retrieve exact values. Reduce gridlines, align numbers by decimal or unit, and highlight only the row or column that supports the title.

## Visual emphasis

Use one dominant emphasis device per slide: contrast color, annotation, enclosure, scale, or position. When everything is highlighted, nothing is prioritized.
